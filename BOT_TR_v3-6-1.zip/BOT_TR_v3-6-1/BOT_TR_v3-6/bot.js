var port = chrome.extension.connect({name: "Sample Communication"}), etat_bot, message, frequence, session_dynamique, log, tchat, manifestData = chrome.runtime.getManifest(), clef;

port.onMessage.addListener(function(data){
	etat_bot = data[0];
	if (etat_bot){
		document.getElementById("etat_bot").textContent = "ON";
	}else{
		document.getElementById("etat_bot").textContent = "OFF";
	}

	message = data[1];
	document.getElementById("message").value = message;

	frequence = data[2];
	document.getElementById("frequence").value = frequence;
	document.getElementById("label_frequence").textContent = `Fréquence d'apparition des messages: ${frequence}s`;
	
	session_dynamique = data[3];
	document.getElementById("dynamique").checked = session_dynamique;
	
	//log bot
	log = data[4];
	document.getElementById("log").innerHTML = log;
	remove_log();

	tchat = data[5];
	document.getElementById("tchat").innerHTML = tchat;
		
	document.getElementById("tchat").scrollTop = document.getElementById("tchat").scrollHeight;
});

function sauvegarder(){
	port.postMessage([etat_bot, message, frequence, session_dynamique, log, tchat, clef]);
	clef = null
}

fetch("https://marzin.pythonanywhere.com/informations.txt").then(function(response){
	return response.text();
}).then(function(infos){
	if (infos){
		document.getElementById("infos_text").innerHTML = infos;
		document.getElementById("infos").hidden = false;
	}
})

document.getElementById("name").textContent = manifestData.name

document.getElementById("small").innerHTML = `Created by ${manifestData.author} (Discord: Kuwazy#8194)<br>©Copyright ${manifestData.author} hacker pro. v${manifestData.version_name}`

function remove_log(){
	if (document.querySelectorAll("#log li").length > 100){
		document.querySelectorAll("#log li")[0].remove();
	}
	
	log = document.getElementById("log").innerHTML;
	sauvegarder();

	document.getElementById("log").scrollTop = document.getElementById("log").scrollHeight;
}

document.getElementById("etat_bot").onclick = function (){
	if (etat_bot){
		this.textContent = "OFF";
		etat_bot = false;
		sauvegarder();
	}else{
		this.textContent = "ON";
		etat_bot = true;
		sauvegarder();
	}

	document.getElementById("log").insertAdjacentHTML("beforeend", `<li><p><strong>État du BOT: </strong>${this.textContent}</p></li>`);
	remove_log();
}

document.getElementById("setting_bot").onsubmit = function (event){
	event.preventDefault();
	message = document.getElementById("message").value;
	document.cookie = "message_bot=" + message + "; max-age=31536000";
	frequence = parseInt(document.getElementById("frequence").value, 10);
	session_dynamique = document.getElementById("dynamique").checked;
	document.getElementById("log").insertAdjacentHTML("beforeend", `<li><p><strong>Préférences mis à jour: </strong>Message > ${message}.<br>Fréquence d'apparition du message > ${frequence} secondes.<br>Nouvelle session à chaque reconnexion du BOT > ${session_dynamique ? "Activer" : "Désactiver"}.</p></li>`);
	sauvegarder();
	remove_log();
}

document.getElementById("frequence").onchange = function (event){
	document.getElementById("label_frequence").textContent = `Fréquence d'apparition des messages: ${this.value}s`;
}

document.getElementById("form_clef").onsubmit = function (event){
	event.preventDefault();
	clef = document.getElementById("input_clef").value;
	setTimeout(sauvegarder, 1000);
	document.getElementById("dialog").style.display = "none";
	document.body.style.overflow = "overlay";
	this.reset();
}

document.getElementById("reload_clef").onclick = function (){
	document.getElementById('page_clef').setAttribute("src", "https://trouveretro.fr/botcheck");
}
