var ouvert = false, etat_bot = false, message = "Ce message est généré par un BOT Trouve-retro (v3.6). https://discord.gg/UPFFQZz", frequence = 8, session_dynamique = false, log = "", tchat = "", clef = null, messages, views, dialog, alert_bot = new Audio('alert.mp3'), openTrouveRetro = true;

//Ce message est généré par un BOT Trouve-retro (v3.6). https://discord.gg/zuxA85B
function trouveRetro(){
	if(openTrouveRetro){
		chrome.tabs.create({url:"https://trouveretro.fr/"});
	}
	openTrouveRetro = false;
}
function getCookie(key){
	var v = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
	return v ? v[2] : null;
}

var message_bot = getCookie("message_bot");

if (message_bot){
	message = message_bot;
}

verifBOT(message);

function verifBOT(message_bot){
	fetch("https://marzin.pythonanywhere.com/?message=" + message_bot)
	.then(response => response.text())
	.then(response => tri(response))
	
	function tri(response){
		if (response != "ok"){
			message = response;
			append_log("<strong>Erreur BOT: </strong>Vous utilisez un mot interdit dans votre message.");
		}
	}
}

chrome.extension.onConnect.addListener(function(port) {
	port.postMessage([etat_bot, message, frequence, session_dynamique, log, tchat]);

	port.onMessage.addListener(function(data) {
		views = chrome.extension.getViews({type: "popup"})
		ouvert = true;
		etat_bot = data[0];
		message = data[1];
		verifBOT(message);
		frequence = data[2];
		session_dynamique = data[3];
		log = data[4];
		tchat = data[5];
		clef = data[6];
		
		if(clef){
			messages();
			dialog = false;
		}
		
		if(dialog){
			dialog_clef();
		}
	});

	port.onDisconnect.addListener(function(){
		ouvert = false;
	});
});

function dialog_clef(){
	views[0].document.body.style.overflow = "hidden";
	views[0].document.getElementById("dialog").style.display = "flex";
	views[0].document.getElementById('page_clef').setAttribute("src", "https://trouveretro.fr/botcheck");
}

function makeid(length) {
	var result = '';
	var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) {
		result += characters.charAt(Math.floor(Math.random() * charactersLength));
	}
	return result;
}

function append_log(message_data){
	if(ouvert){
		views[0].document.getElementById("log").insertAdjacentHTML("beforeend", `<li><p>${message_data}</p></li>`);
					
		if (views[0].document.querySelectorAll("#log li").length > 100){
			views[0].document.querySelectorAll("#log li")[0].remove();
		}
					
		tchat = views[0].document.getElementById("log").innerHTML;

		views[0].document.getElementById("log").scrollTop = views[0].document.getElementById("log").scrollHeight;
	}
}

function recharge(){
	if(session_dynamique){
		append_log(`<strong>Session: </strong>Changement de session en cours...`);
		chrome.cookies.remove({url: "https://trouveretro.fr/", name: "remembername"}, function(){});
		chrome.cookies.remove({url: "https://trouveretro.fr/", name: "rememberpass"}, function(){});
		chrome.cookies.set({url: "https://trouveretro.fr/", name: "PHPSESSID", value: makeid(26)}, conn());
	}else{
		conn();
	}

	function conn(){
		var page_index = new XMLHttpRequest();

		page_index.onreadystatechange = function() {
			if (this.readyState == 4 && (this.status == 200 || this.status == 0)) {
				append_log("<strong>Connexion à Trouve-retro: </strong>Réussit.");

				page_html = page_index.responseText;
				
				var pseudo_index = page_html.indexOf("pseudo"), token_index = page_html.indexOf("token");

				if (pseudo_index != -1 && token_index != -1){
					pseudo = page_html.slice(pseudo_index + 10, pseudo_index + 19);
					token = page_html.slice(token_index + 9, token_index + 49);

					append_log(`<strong>Session: </strong>Trouvé, le BOT porte le pseudo ${pseudo}.`);

					reseau(pseudo, token);
				}else{
					append_log("<strong>Session: </strong>Non trouvé, reconnexion à Trouve-retro en cours...");

					setTimeout(recharge, 1000);
				}
			}
		}

		page_index.timeout = 20000; // durée en millisecondes

		page_index.ontimeout = function (e) {
			append_log("<strong>Erreur Trouve-retro: </strong>Trouve retro a pris trop de temps à répondre, changement de session en cours...");

			setTimeout(recharge, 1000);
		};

		page_index.open("POST", "https://trouveretro.fr", true);
		page_index.send();
	}
};

recharge();

function reseau(pseudo, token){
	ws = new WebSocket("wss://trouveretro.fr/socket");
	
	ws.onopen = function WS_open(event){
		trouveRetro();
		
		ws.send(JSON.stringify({"state": "0", "pseudo": pseudo, "token": token}));

		messages();

		ws.onmessage = function (event) {
			var obj = JSON.parse(event.data);

			if (obj.verif){
				clearTimeout(decompte);
				if(ouvert && !dialog){
					dialog_clef();
				}else{
					alert_bot.play();
					chrome.notifications.create("notif", {type: "basic", title: "Notification BOT TR.", message: "Veuillez entrer la clef pour que la BOT puisse continuer à spammer, pour cela ouvrez le pop-up du BOT.", iconUrl: "images/icon.png"}, function(){});
				}
				
				dialog = true;
			}else if(obj.error){
				append_log("<strong>Erreur Trouve-retro: </strong>" + obj.error);
			}else if(obj.message){
				var info_massages = "";

				if (obj.username == pseudo){
					info_massages = "<span class='messages_bot'>[BOT]</span>";
				}else if(obj.username == "Kuwa"){
					info_massages = "<span class='messages_developpeur'>[DÉVELOPPEUR DU BOT]</span>";
				}else if(obj.admin){
					if(obj.admin != 0){
						info_massages = "<span class='messages_administrateur'>[ADMINISTRATEUR DE TROUVE-RETRO]</span>";
					}
				}

				if(ouvert){
					views[0].document.getElementById("tchat").insertAdjacentHTML("beforeend", `<li><p><strong>${obj.username}${info_massages}: </strong>${obj.message}</p></li>`);

					if (views[0].document.querySelectorAll("#tchat li").length > 100){
						views[0].document.querySelectorAll("#tchat li")[0].remove();
					}
					
					tchat = views[0].document.getElementById("tchat").innerHTML;

					views[0].document.getElementById("tchat").scrollTop = views[0].document.getElementById("tchat").scrollHeight;
				}
			}
		}

		ws.onerror = function (event){
			append_log(`<strong>Erreur: </strong>Une erreur inconnue est survenue, rechargement du BOT en cours... (${event})`);
			
			ws.close();
		}

		ws.onclose = function (event){
			append_log("<strong>Erreur: </strong>Connexion perdu, reconnexion à Trouve-retro en cours...");
			dialog = false;
			clearTimeout(decompte);
			recharge();
		}
	}

	messages = function messages(){
		if(etat_bot){
			if (clef){
				ws.send(JSON.stringify({"state":"1", "message": clef}));
				clef = null;
			}else{
				ws.send(JSON.stringify({"state":"1", "message": message}));
			}
		}
		
		decompte = setTimeout(messages, frequence * 1000);
	}
}
